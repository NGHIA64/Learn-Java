package BT1_Chuong5;

public interface Ishape {
	float getArea();

	float getPerimeter();
}
